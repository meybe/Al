# -*- coding: utf-8 -*-
import LINETCR
from LINETCR.lib.curve.ttypes import *
from datetime import datetime
import ast,re,time,random,sys,json,codecs,threading,glob,tempfile
from gtts import gTTS
from time import sleep
import os,six, urllib, wikipedia, requests, bs4, html5lib
from bs4 import BeautifulSoup

with open('token.json', 'r') as fp:
    akun = json.load(fp)
    
cl = LINETCR.LINE()
#kk = LINETCR.LINE()
#wb = LINETCR.LINE()

if akun['token1'] == "Ep38PJxk66Glwx0ojU6c.ueLeCJvKvdpbtVTadGiEla.SXAFomRSdwyICki8pp8Aa1u0xfJ2ffsc74QMPA/XZ9o=":
    cl.login(token='Ep38PJxk66Glwx0ojU6c.ueLeCJvKvdpbtVTadGiEla.SXAFomRSdwyICki8pp8Aa1u0xfJ2ffsc74QMPA/XZ9o=')
else:
    cl.login(token=akun['token1'])
#if akun['token2'] == "EpPvGLfqN4cGBQiapT38.LnAR6cwl1HBu8jV4sb9Cwa.CT6PYMszPYzGFd//q5DXxfXeIClgM2GL1ecQKDd7ZGE=":
    #kk.login(token='EpPvGLfqN4cGBQiapT38.LnAR6cwl1HBu8jV4sb9Cwa.CT6PYMszPYzGFd//q5DXxfXeIClgM2GL1ecQKDd7ZGE=')
#else:
 #   kk.login(token=akun['token2'])
#if akun['token3'] == "EppByPDTz6jcI0HR1iDb.Gl2FmoVBdJvP5zrS8+WsIW.whKl/cTnfP52tvSL+uqFcn9bW2bhjUBcndxtOfYNg/I=":
    #wb.login(token='EppByPDTz6jcI0HR1iDb.Gl2FmoVBdJvP5zrS8+WsIW.whKl/cTnfP52tvSL+uqFcn9bW2bhjUBcndxtOfYNg/I=')
#else:
   # wb.login(token=akun['token3'])

    
cl.loginResult()
#kk.loginResult()
#wb.loginResult()

print ("login success")



KAC=[kk]
mid = cl.getProfile().mid
#Bmid = kk.getProfile().mid
#Wmid = wb.getProfile().mid
print ("Main BOT " + mid)
akun['token1'] = cl.authToken
#print ("Assist BOT: " + Bmid)
#akun['token2'] = kk.authToken
#print ("Assist BOT: " + Wmid)
#akun['token3'] = wb.authToken
with open('token.json', 'w') as fp:
    json.dump(akun, fp, sort_keys=True, indent=4)

Bots=[mid]
changeimage = False
changeimage1 = False

backup = cl.getProfile()
#backup1 = kk.getProfile()
#backup2 = wb.getProfile()
strt = datetime.now()

periksa = {
        'autojoin':"off",
    'addbanmode':{},
    'delbanmode':{},
    'banlist':{},
    'addfriend':{},
        'autocancel':{},
        'autopurge':{},
        'lockqr':{},
    'liketl':{},
        'wl':{},
        'addwl':{},
        'delwl':{},
    'undang':{},
        'tmimic':{},
        'mimic':False,
        'message':"",
        'autolike':False,
        'autoadd':False,
        'autorejc':False
        }

wait = {
    "Sider":{},
    "lang":"JP",
    "Sambutan":False
     }

sider = {
    'readPoint':{},
    'readMember':{},
    'setTime':{},
    'ROM':{}
    }
setTime = {}
setTime = sider['setTime']

cctv = {
    "cyduk":{},
    "point":{},
    "sidermem":{}
}

wait2 = {
    "readPoint":{},
    "readMember":{},
    "setTime":{},
    "ROM":{}
    }

setTime = {}
setTime = wait2['setTime']
mulai = time.time() 

with open('settingan.json', 'r') as fp:
    periksa = json.load(fp)
with open('sider.json', 'r') as fp:
    sider = json.load(fp)

def sendMessage(to, text, contentMetadata={}, contentType=0):
    mes = Message()
    mes.to, mes.from_ = to, profile.mid
    mes.text = text
    mes.contentType, mes.contentMetadata = contentType, contentMetadata
    if to not in messageReq:
        messageReq[to] = -1
    messageReq[to] += 1

agent = {'user-Agent': "Mozilla/4.0(compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322; .NET CLR 2.0.50/27; .NET CLR 3.0.04506.0)"} 

def translate(to_translate, to_language="auto", language="auto"):
    base_link="http://translate.google.com/m?hl=%s&sl=%s&q=%s"
    if(six.PY2):
        link = base_link % (to_language, language, urllib.pathname2url(to_translate))
        request = urllib2.Request(link, headers=agent)
        page = urllib2.urlopen(request).read()
    else:
        link = base_link % (to_language, language, urllib.parse.quote(to_translate))
        request = urllib.request.Request(link, headers=agent)
        page = urllib.request.urlopen(request).read().decode('utf-8')
    expr = r'class="t0">(.*?)<'
    result = re.findall(expr,page)
    if(len(result)==0):
        return("")
    return(result[0])
    
def download_page(url):
    version = (3,0)
    cur_version = sys.version_info
    if cur_version >= version:     
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
            req = urllib.request.Request(url, headers = headers)
            resp = urllib.request.urlopen(req)
            respData = str(resp.read())
            return respData
        except Exception as e:
            print(str(e))
    else:                        
        import urllib2
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.27 Safari/537.17"
            req = urllib2.Request(url, headers = headers)
            response = urllib2.urlopen(req)
            page = response.read()
            return page
        except:
            return"Page Not found"
            
def _images_get_next_item(s):
    start_line = s.find('rg_di')
    if start_line == -1:    
        end_quote = 0
        link = "no_links"
        return link, end_quote
    else:
        start_line = s.find('"class="rg_meta"')
        start_content = s.find('"ou"',start_line+1)
        end_content = s.find(',"ow"',start_content+1)
        content_raw = str(s[start_content+6:end_content-1])
        return content_raw, end_content
        
def _images_get_all_items(page):
    items = []
    while True:
        item, end_content = _images_get_next_item(page)
        if item == "no_links":
            break
        else:
            items.append(item)      
            time.sleep(0.1)        
            page = page[end_content:]
    return items
    
def MENTION(to, nama):
    zx = ""
    zxc = ""
    nm = nama
    for x in nm:
        pesan = ''
        pesan2 = pesan+"@a\n"
        xlen = str(len(zxc))
        xlen2 = str(len(zxc)+len(pesan2)-1)
        zx += """{"S":"""+json.dumps(xlen)+""","E":"""+json.dumps(xlen2)+""","M":"""+json.dumps(x)+"},"""
        
        zxc += pesan2
    zx = (zx[:int(len(zx)-1)])
    print (zx)
    msg = Message()
    msg.to = to
    msg.text = zxc
    msg.contentMetadata = {'MENTION':'{"MENTIONEES":['+zx+']}','EMTVER':'4'}
    try:
        cl.sendMessage(msg)
    except Exception as e:
        print (e)

def kick_all(to,target):
                    msg = Message()
                    msg.to = to
                    try:
                                kb.kickoutFromGroup(msg.to,[target])
                    except:
                                pass

def restart_program():
    python = sys.executable
    os.execl(python, python, * sys.argv)
    


def bot(op):
    global changeimage
    global changeimage1
    helpMessage =""" ༺₦Ξ࿋(´ﻌ`)₮ΞᏜѪℬ࿋₮™༻
╔═══════════════════
║          ʜᴇʟᴘ menu
╠═══════════════════
║☆ 「 Myhelp」
║☆ 「 Me」
║☆ 「 Mid」
║☆ 「 Gid」
║☆ 「 Mygroups」
║☆ 「 Kontak: 'Mid'」
║☆ 「 Message change: 'text'」
║☆ 「 Message cek」
║☆ 「 Reboot」
║☆ 「 Say 'text'」
║☆ 「 Music 'text'」
║☆ 「 Lirik」
║☆ 「 Pict ig 'link'」
║☆ 「 Cs: 'status'」
║☆ 「 Cn: 'name'」
║☆ 「 Gc」
║☆ 「 Ban on/off」
║☆ 「 Link on/off」
║☆ 「 Mimic:on」
║☆ 「 Cek ban」
║☆ 「 Clear ban」
║☆ 「 Unban on/off」
║☆ 「 wl on/off」
║☆ 「 unwl on/off @」
║☆ 「 Wl add @」
║☆ 「 Wl del @」
║☆ 「 All pict」
║☆ 「 Mypict 」
║☆ 「 Mycover 」
║☆ 「 Times」
║☆ 「 Name」
║☆ 「 Bio」
║☆ 「 Copy @tag」
║☆ 「 Backup」
║☆ 「 Rgroups」
║☆ 「 Whitelist」
║☆ 「 Mimic list」
║☆ 「 Clean ban」
║☆ 「 Clear ban」
║☆ 「 Clear wl」
║☆ 「 Gift1-5」
║☆ 「 Voice: 'text'」
║☆ 「 Tagmem」
║☆ 「 Bcgroup: 」
║☆ 「 Pictgroups」
║☆ 「 Change pict」
║☆ 「 Change pict group」
║☆ 「 Spam 'text'」
║☆ 「 Getall @tag」
║☆ 「 Contact @tag」
║☆ 「 Status @tag」
║☆ 「 Getinfo @tag」
║☆ 「 Mid @tag」
║☆ 「 Pict @tag」
║☆ 「 Cover @tag」
║☆ 「 Name @tag」
║☆ 「 Mimic @tag」
║☆ 「 Unmimic @tag」
║☆ 「 Ban add @tag」
║☆ 「 Ban del @tag」
║☆ 「 Kick @tag」
║☆ 「 Vkick @tag」
╠═══════════════════
║          ʜᴇʟᴘ sᴇᴛᴛɪɴɢ
╠═══════════════════
║☆ 「 Sider on/off」
║☆ 「 Set on/off」
║☆ 「 Set view」
║☆ 「 Welcome on/off」
║☆ 「 Autojoin:on/off」
║☆ 「 Vkick @tag」
║☆ 「 Autoadd:on/off」
║☆ 「 Autolike:on/off」
║☆ 「 Autopurge:on/off」
║☆ 「 Block qr:on/off」
║☆ 「 Blockinvite:on/off」
║☆ 「 Protection:on」
║☆ 「 Autoreject:on/off」
╠═══════════════════
║༺₦Ξ࿋(´ﻌ`)₮ΞᏜѪℬ࿋₮™༻&
║✍Ŧ€₳M☬ж☬Ħ₳ʗҜ฿❂Ŧ✈๛
╚═══════════════════
"""
    try:
        
        if op.type == 0:
            return
        if op.type == 5:
            if periksa['autoadd'] == True:
                cl.findAndAddContactsByMid(op.param1)
                if (periksa["message"] in [""," ","\n",None]):
                    pass
                else:
                    cl.sendText(op.param1,str(periksa["message"]))
            else:
                pass
        if op.type == 17:
          if wait["Sambutan"] == True:
            if op.param2 in Bots:
                return
            ginfo = cl.getGroup(op.param1)
            contact = cl.getContact(op.param2)
            image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
            cl.sendText(op.param1,"Hallo " + cl.getContact(op.param2).displayName + "\nWelcome To ☞ " + str(ginfo.name) + " ☜" + "\nBudayakan Cek Note\nDan Semoga Betah Disini ^_^")
            cl.sendImageWithURL(op.param1,image)
            print ("MEMBER JOIN TO GROUP")

        if op.type == 15:
          if wait["Sambutan"] == True:
            if op.param2 in Bots:
                return
            cl.sendText(op.param1,"Good Bye " + cl.getContact(op.param2).displayName +  "\nSee You Next Time . . . (p′︵‵。) 🤗")
            print ("MEMBER HAS LEFT THE GROUP")               
        if op.type == 55:
                try:
                    if cctv['cyduk'][op.param1]==True:
                        if op.param1 in cctv['point']:
                            Name = cl.getContact(op.param2).displayName
                            if Name in cctv['sidermem'][op.param1]:
                                pass
                            else:
                                cctv['sidermem'][op.param1] += "\n• " + Name
                                if " " in Name:
                                    nick = Name.split(' ')
                                    if len(nick) == 2:
                                        cl.sendText(op.param1, "Haii " +  nick[0] +  "\nNgintip Aja Niih. . .\nChat Kek Idiih (-__-)   ")
                                        MENTION(op.param1,[op.param2])
                                    else:
                                        cl.sendText(op.param1, "Haii " +  nick[1] + "\nBetah Banget Jadi Penonton. . .\nChat Napa (-__-)   ")
                                        MENTION(op.param1,[op.param2])  
                                else:
                                    cl.sendText(op.param1, "Haii " + Name +  "\nNgapain Kak Ngintip Aja???\nSini Gabung Chat...   ")
                                    MENTION(op.param1,[op.param2])
                        else:
                            pass
                    else:
                        pass
                except:
                    pass
        else:
            pass
                    
        if op.type == 11:
          if op.param1 in periksa["lockqr"]:
             if op.param2 not in Bots and op.param2 not in periksa["wl"]:
                X = cl.getGroup(op.param1)
                if X.preventJoinByTicket == False:
                  X.preventJoinByTicket = True
                  cl.updateGroup(X)
                  if op.param2 in periksa["banlist"]:
                    cl.kickoutFromGroup(op.param1,[op.param2])
                  else:
                    periksa["banlist"][op.param2] = True
                    with open('settingan.json', 'w') as fp:
                      json.dump(periksa, fp, sort_keys=True, indent=4) 
        if op.type == 17:
          if op.param1 in periksa["autopurge"]:
            G = cl.getGroup(op.param1)
            if G is None:
                pass
            else:
                gMembMids = [contact.mid for contact in G.members]
                matched_list = []
                for tag in periksa["banlist"]:
                        matched_list+=filter(lambda str: str == tag, gMembMids)
                if matched_list == []:
                        pass
                for jj in matched_list:
                    try:
                        wb.kickoutFromGroup(op.param1,[jj])
                    except:
                      try:
                        kk.kickoutFromGroup(op.param1,[jj])
                      except:
                            cl.kickoutFromGroup(op.param1,[jj])

        if op.type == 13:
            if mid in op.param3:
              if periksa["autojoin"] == "wl":
                if op.param2 in periksa["wl"]:
                  cl.acceptGroupInvitation(op.param1)
                else:
                    if periksa['autorejc'] == True:
                        cl.rejectGroupInvitation(op.param1)
                    else:
                        pass
              elif periksa["autojoin"] == "all":
                  cl.acceptGroupInvitation(op.param1)
              else:
                  if periksa['autorejc'] == True:
                        cl.rejectGroupInvitation(op.param1)
                  else:
                        pass
            
            else:
                if op.param2 not in Bots and op.param2 not in periksa["wl"]:
                  group_id=op.param1
                  if group_id in periksa["autocancel"]:
                    group = cl.getGroup(op.param1)
                    if group.invitee is None:
                       pass
                    else:
                        gInviMids = [contact.mid for contact in group.invitee]
                        try:
                            kk.cancelGroupInvitation(op.param1, gInviMids)
                        except:
                            try:
                                wb.cancelGroupInvitation(op.param1, gInviMids)
                            except:
                                cl.cancelGroupInvitation(op.param1, gInviMids)
                                
                if op.param1 in periksa["autopurge"]:        
                    Inviter = op.param3.replace("",',')
                    InviterX = Inviter.split(",")
                    matched_list = []
                    for tag in periksa["banlist"]:
                        matched_list+=filter(lambda str: str == tag, InviterX)
                    if matched_list == []:
                        pass
                    else:
                        kk.cancelGroupInvitation(op.param1, matched_list)
            
        if op.type == 19:
            if op.param1 in periksa["protect"]:
                if op.param2 not in Bots and op.param2 not in periksa['wl']:
                    try:
                        kk.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            wb.kickoutFromGroup(op.param1,[op.param2])
                        except:
                            cl.kickoutFromGroup(op.param1,[op.param2])
                try:
                        kk.inviteIntoGroup(op.param1,[op.param3])
                except:
                        try:
                            wb.inviteIntoGroup(op.param1,[op.param3])
                        except:
                            cl.inviteIntoGroup(op.param1,[op.param3])
                if op.param2 in periksa["banlist"]:
                        pass
                elif op.param2 in periksa["wl"]:
                  pass 
                else:
                        periksa["banlist"][op.param2] = True
                        with open('settingan.json', 'w') as fp:
                           json.dump(periksa, fp, sort_keys=True, indent=4)
                   
            if mid in op.param3:
                     try:
                         kk.kickoutFromGroup(op.param1,[op.param2])
                     except:
                         wb.kickoutFromGroup(op.param1,[op.param2])
                     G = kk.getGroup(op.param1)
                     G.preventJoinByTicket = False
                     kk.updateGroup(G)
                     Ti = kk.reissueGroupTicket(op.param1)
                     cl.acceptGroupInvitationByTicket(op.param1,Ti)
                     X = cl.getGroup(op.param1)
                     X.preventJoinByTicket = True
                     cl.updateGroup(X)
                     Ti = cl.reissueGroupTicket(op.param1)
                     if op.param2 in periksa["banlist"]:
                        pass
                     elif op.param2 in periksa["wl"]:
                        pass
                     else:
                        periksa["banlist"][op.param2] = True
            if Bmid in op.param3:
                     try:
                         wb.kickoutFromGroup(op.param1,[op.param2])
                     except:
                         cl.kickoutFromGroup(op.param1,[op.param2])
                     X = cl.getGroup(op.param1)
                     X.preventJoinByTicket = False
                     cl.updateGroup(X)
                     Ti = cl.reissueGroupTicket(op.param1)
                     kk.acceptGroupInvitationByTicket(op.param1,Ti)
                     G = kk.getGroup(op.param1)
                     G.preventJoinByTicket = True
                     kk.updateGroup(G)
                     Ticket = kk.reissueGroupTicket(op.param1)
                     if op.param2 in periksa["banlist"]:
                        pass
                     elif op.param2 in periksa["wl"]:
                        pass 
                     else:
                        periksa["banlist"][op.param2] = True
                        with open('settingan.json', 'w') as fp:
                           json.dump(periksa, fp, sort_keys=True, indent=4)
            if Wmid in op.param3:
                     try:
                         kk.kickoutFromGroup(op.param1,[op.param2])
                     except:
                         cl.kickoutFromGroup(op.param1,[op.param2])
                     X = cl.getGroup(op.param1)
                     X.preventJoinByTicket = False
                     cl.updateGroup(X)
                     Ti = cl.reissueGroupTicket(op.param1)
                     wb.acceptGroupInvitationByTicket(op.param1,Ti)
                     G = kk.getGroup(op.param1)
                     G.preventJoinByTicket = True
                     kk.updateGroup(G)
                     Ticket = kk.reissueGroupTicket(op.param1)
                     if op.param2 in periksa["banlist"]:
                        pass
                     elif op.param2 in periksa["wl"]:
                        pass 
                     else:
                        periksa["banlist"][op.param2] = True
                        with open('settingan.json', 'w') as fp:
                            json.dump(periksa, fp, sort_keys=True, indent=4)
        if op.type == 55:
            try:
                if op.param1 in sider['readPoint']:
            
                    if op.param2 in sider['readMember'][op.param1]:
                        pass
                    else:
                        sider['readMember'][op.param1] += op.param2
                    sider['ROM'][op.param1][op.param2] = op.param2
                    with open('sider.json', 'w') as fp:
                       json.dump(sider, fp, sort_keys=True, indent=4)
                else:
                    pass
            except:
                pass
        if op.type == 26:
            msg = op.message
            if periksa['mimic'] == True:
                if msg.from_ in periksa['tmimic']:
                    if msg.text.lower() not in helpMessage:
                        cl.sendMessage(msg)
                else:
                    pass
            else:
                pass
        if op.type == 25: #disini :v
            msg = op.message
            pesan = msg.text
            if msg.contentType == 1:
                if msg.to in periksa["cpg"]:
                  try:
                   cl.changePG(msg.to, msg.id)
                   del periksa["cpg"][msg.to]
                   with open('settingan.json', 'w') as fp:
                     json.dump(periksa, fp, sort_keys=True, indent=4)
                  except Exception as E:
                    print (E)
                    try:
                      cl.changePG(msg.to, msg.id)
                      del periksa["cpg"][msg.to]
                      with open('settingan.json', 'w') as fp:
                        json.dump(periksa, fp, sort_keys=True, indent=4)
                    except Exception as E:
                      cl.sendText(msg.to, "Failed")
                if changeimage:
                    changeimage = False
                    msgid = msg.id
                    url = "https://obs-de.line-apps.com/os/m/%s"%msgid
                    img = cl.dl_line(url)
                    cl.upload_pp(img)
                    cl.sendText(msg.to,"Profile image updated.")
                if msg.to in periksa["cpp11"]:
                  try:
                   cl.changePP(msg.to, msg.id, mid)
                   del periksa["cpp11"][msg.to]
                   with open('settingan.json', 'w') as fp:
                     json.dump(periksa, fp, sort_keys=True, indent=4)
                  except Exception as E:
                    print (E)
                    try: 
                      cl.changePP(msg.to, msg.id, mid)
                      del periksa["cpp11"][msg.to]
                      with open('settingan.json', 'w') as fp:
                        json.dump(periksa, fp, sort_keys=True, indent=4)
                    except Exception as E:
                      cl.sendText(msg.to, "Failed")
                if msg.to in periksa["cpp1"]:
                  try:
                   kk.changePP(msg.to, msg.id, Bmid)
                   del periksa["cpp1"][msg.to]
                   with open('settingan.json', 'w') as fp:
                     json.dump(periksa, fp, sort_keys=True, indent=4)
                  except Exception as E:
                    print (E)
                    try:
                      kk.changePP(msg.to, msg.id, Bmid)
                      del periksa["cpp1"][msg.to]
                      with open('settingan.json', 'w') as fp:
                        json.dump(periksa, fp, sort_keys=True, indent=4)
                    except Exception as E:
                      kk.sendText(msg.to, "Failed")
                if msg.to in periksa["cpp2"]:
                  try:
                   wb.changePP(msg.to, msg.id, Wmid) 
                   del periksa["cpp2"][msg.to]
                   with open('settingan.json', 'w') as fp:
                     json.dump(periksa, fp, sort_keys=True, indent=4)
                  except Exception as E:
                    print (E)
                    try: 
                      wb.changePP(msg.to, msg.id, Wmid)
                      del periksa["cpp2"][msg.to]
                      with open('settingan.json', 'w') as fp:
                        json.dump(periksa, fp, sort_keys=True, indent=4)
                    except Exception as E:
                      wb.sendText(msg.to, "Failed")            
        
            if msg.contentType == 13:
               if msg.to in periksa["addbanmode"]:
                  if msg.contentMetadata["mid"] in periksa["banlist"]:
                     cl.sendText(msg.to, "Contact is already in list")
                  elif msg.contentMetadata["mid"] in periksa["wl"]:
                            cl.sendText(msg.to,"Can't banned wl")
                  else:
                        periksa["banlist"][msg.contentMetadata["mid"]] = True
                        with open('settingan.json', 'w') as fp:
                             json.dump(periksa, fp, sort_keys=True, indent=4)
                        cl.sendText(msg.to, "Added 􀜁􀄯ok􏿿")
               elif msg.to in periksa["delbanmode"]:
                   if msg.contentMetadata["mid"] in periksa["banlist"]:
                        del periksa["banlist"][msg.contentMetadata["mid"]]
                        cl.sendText(msg.to,"Deleted 􀜁􀄯ok􏿿")
                        with open('settingan.json', 'w') as fp:
                            json.dump(periksa, fp, sort_keys=True, indent=4)
                   else:
                        cl.sendText(msg.to,"Contact not in list")
              
               elif msg.to in periksa["addwl"]:
                   if msg.contentMetadata["mid"] in periksa["wl"]:
                      cl.sendText(msg.to, "Contact already in list")
                   else:
                        periksa["wl"][msg.contentMetadata["mid"]] = True
                        with open('settingan.json', 'w') as fp:
                              json.dump(periksa, fp, sort_keys=True, indent=4)
                        cl.sendText(msg.to, "Added 􀜁􀄯ok􏿿")
               elif msg.to in periksa["delwl"]:
                   if msg.contentMetadata["mid"] in periksa["wl"]:
                        del periksa["wl"][msg.contentMetadata["mid"]]
                        cl.sendText(msg.to,"Deleted 􀜁􀄯ok􏿿")
                        with open('settingan.json', 'w') as fp:
                             json.dump(periksa, fp, sort_keys=True, indent=4)
                   else:
                        cl.sendText(msg.to,"Contact not in list")
               elif msg.to in periksa["addtarget"]:
                   if msg.contentMetadata["mid"] in periksa["target"]:
                      cl.sendText(msg.to, "Contact already in list")
                   else:
                        periksa["target"][msg.contentMetadata["mid"]] = True
                        with open('settingan.json', 'w') as fp:
                              json.dump(periksa, fp, sort_keys=True, indent=4)
                        cl.sendText(msg.to, "Added 􀜁􀄯ok􏿿")
               elif msg.to in periksa["deltarget"]:
                   if msg.contentMetadata["mid"] in periksa["target"]:
                        del periksa["target"][msg.contentMetadata["mid"]]
                        cl.sendText(msg.to,"Deleted 􀜁􀄯ok􏿿")
                        with open('settingan.json', 'w') as fp:
                             json.dump(periksa, fp, sort_keys=True, indent=4)
                   else:
                        cl.sendText(msg.to,"Contact not in list")
               elif msg.to in periksa["gift2"]:
                      target = msg.contentMetadata["mid"]
                      lol = msg.to
                      msg.contentType = 9
                      msg.contentMetadata = { 'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58',
                                        'PRDTYPE':'THEME',
                                        'MSGTPL':'12'}
                      msg.to = target
                      msg.text == None
                      for zx in range(0,periksa['gift2jumlah']):

                        cl.sendMessage(msg)
                        kk.sendMessage(msg)
                        wb.sendMessage(msg)
                      del periksa["gift2"][lol]
                      try:
                            cl.sendText(lol,"Done 􀜁􀄯ok􏿿")
                      except:
                            pass
                      try:
                            kk.sendText(lol,"Done 􀜁􀄯ok􏿿")
                      except:
                            pass
                      try:
                            wb.sendText(lol,"Done 􀜁􀄯ok􏿿")
                      except:
                            pass
                        
            
                      with open('settingan.json', 'w') as fp:
                           json.dump(periksa, fp, sort_keys=True, indent=4)
                        
               elif msg.to in periksa["gift"]:
                        target = msg.contentMetadata["mid"]
                        lol = msg.to
                        msg.contentType = 9
                        msg.contentMetadata = { 'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58',
                                        'PRDTYPE':'THEME',
                                        'MSGTPL':'12'}
                        msg.to = target
                        msg.text == None
                        cl.sendMessage(msg)
                        kk.sendMessage(msg)
                        wb.sendMessage(msg)
                        del periksa["gift"][lol]
                        try:
                            cl.sendText(lol,"Done 􀜁􀄯ok􏿿")
                        except:
                            pass
                        try:
                            kk.sendText(lol,"Done 􀜁􀄯ok􏿿")
                        except:
                            pass
                        try:
                            wb.sendText(lol,"Done 􀜁􀄯ok􏿿")
                        except:
                            pass
                        with open('settingan.json', 'w') as fp:
                             json.dump(periksa, fp, sort_keys=True, indent=4)
                   
               
            
            elif pesan is None:
                return
            if "myhelp" == pesan.lower():
                    cl.sendText(msg.to,helpMessage)
            if "talk1" == pesan.lower():
                    cl.sendText(msg.to,helpMessage1)
            if "key1" == pesan.lower():
                    cl.sendText(msg.to,helpMessage2)                    
#            elif "liketype:" in pesan.lower():
#                xpesan = pesan.lower()
#                xres = xpesan.replace("liketype:","")
#                if xres == "":
#                    pass
#                else:
#                    number = int(xres)
#                    periksa['like'] = number
#                    with open('settingan.json', 'w') as fp:
#                        json.dump(periksa, fp, sort_keys=True, indent=4)
#                    cl.sendText(msg.to,"Like type set to %s"%(xres))
            elif "comment:" in pesan.lower():
                xpesan = pesan.lower()
                xres = xpesan.replace("comment:","")
                if xres == "":
                    pass
                else:
                    periksa['comment'] = xres
                    with open('settingan.json', 'w') as fp:
                        json.dump(periksa, fp, sort_keys=True, indent=4)
                    cl.sendText(msg.to,"change to %s"%(xres))
#            elif ".add " in pesan.lower():
#                xpesan = pesan.lower()
#               xres = xpesan.replace(".add ","")
#                if xres not in helpMessage:
#                  yres = xres.replace(xres[:1]+":","")
#                  abjadlist = yres.split(' ')
#                  periksa['emo'][xres[:1]] = abjadlist
#                  with open('settingan.json', 'w') as fp:
#                     json.dump(periksa, fp, sort_keys=True, indent=4)
#                  cl.sendText(msg.to,"emoji %s added to list"%(yres))
#            elif ".emo " in pesan.lower():
#                xpesan = pesan.lower()
#                emox = xpesan.replace(".emo ","")
#               if emox not in helpMessage:
#                 jmlh = len(emox)
#                  msk = int(0)
#                 mskx = int(0)
#                 listx = []
#                 lol = ""
#                  for x in range(jmlh):
#                     listx.append(emox[msk])
#                     msk += 1
#                  for x in listx:
#                    mskx += 1
#                     if x in periksa['emo']:
#                        lol += random.choice(periksa['emo'][x])
#                     else:
#                       lol =+ ' '
#                  cl.sendText(msg.to,"%s"%(lol))
            elif "music " in pesan.lower():
                xpesan = pesan.lower()
                songname = xpesan.replace("music ","")
                params = {'songname':songname}
                r=requests.get('https://ide.fdlrcn.com/workspace/yumi-apis/joox?'+urllib.parse.urlencode(params))
                data = r.text
                data=json.loads(data)
                
                for song in data:
                    cl.sendText(msg.to,"Music\n\n%s (%s)\nDownload: %s"%(song[0],song[1],song[4]))
                    cl.sendAudioWithURL(msg.to,song[4])
            elif "lirik " in pesan.lower():
                xpesan = pesan.lower()
                songname = xpesan.replace("lirik ","")
                params = {'songname':songname}
                r=requests.get('https://ide.fdlrcn.com/workspace/yumi-apis/joox?'+urllib.parse.urlencode(params))
                data = r.text
                data=json.loads(data)
                for song in data:
                    cl.sendText(msg.to,"%s \n\n %s"%(song[0],song[5]))
            elif "Spam " in pesan:
                   txt = pesan.split(" ")
                   jmlh = int(txt[2])
                   teks = msg.text.replace("Spam "+str(txt[1])+" "+str(jmlh)+ " ","")
                   tulisan = jmlh * (teks+"\n")
                  #Haku sholeh <3
                   if txt[1] == "on":
                        if jmlh <= 10000:
                             for x in range(jmlh):
                                   cl.sendText(msg.to, teks)
                        else:
                               cl.sendText(msg.to, "ARE YOU FUCKING KIDDING ME? ")
                   elif txt[1] == "off":
                         if jmlh <= 10000:
                               cl.sendText(msg.to, tulisan)
                         else:
                               cl.sendText(msg.to, "ARE YOU FUCKING KIDDING ME? ")

            elif msg.text in ["Welcome on"]:
                if wait["Sambutan"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Sambutan Di Aktifkanヾ(*´∀｀*)ﾉ")
                else:
                    wait["Sambutan"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Sudah Onヽ(´▽｀)/")

            elif msg.text in ["Welcome off"]:
                if wait["Sambutan"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Sambutan Di Nonaktifkan(　＾∇＾)")
                else:
                    wait["Sambutan"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Sudah Off(p′︵‵。)")
                        
            elif "autojoin:" in pesan.lower():
                xpesan = pesan.lower()
                xres = xpesan.replace("autojoin:","")
                if xres == "off":
                    periksa['autojoin'] = "off"
                    cl.sendText(msg.to,"Auto Join Set to OFF")
                elif xres == "on":
                    periksa['autojoin'] = "all"
                    cl.sendText(msg.to,"Auto Join Set to All")
                elif xres == "wl":
                    periksa['autojoin'] = "wl"
                    cl.sendText(msg.to,"Auto Join Set to Wl")
            elif "autolike:" in pesan.lower():
                xpesan = pesan.lower()
                xres = xpesan.replace("autolike:","")
                if xres == "off":
                    periksa['autolike'] = False
                    cl.sendText(msg.to,"Auto Like already Off 􀜁􀄰no􏿿")
                elif xres == "on":
                    periksa['autolike'] = True
                    cl.sendText(msg.to,"Auto Like already On 􀜁􀄯ok􏿿")
            elif "autoadd:" in pesan.lower():
                xpesan = pesan.lower()
                xres = xpesan.replace("autoadd:","")
                if xres == "off":
                    periksa['autoadd'] = False
                    cl.sendText(msg.to,"Auto Add already Off 􀜁􀄰no􏿿")
                elif xres == "on":
                    periksa['autoadd'] = True
                    cl.sendText(msg.to,"Auto Add already On 􀜁􀄯ok􏿿")
            elif "autopurge:" in pesan.lower():
                xpesan = pesan.lower()
                xres = xpesan.replace("autopurge:","")
                if xres == "off":
                    del periksa['autopurge'][msg.to]
                    cl.sendText(msg.to,"Auto Purge already Off 􀜁􀄰no􏿿")
                elif xres == "on":
                    periksa['autopurge'][msg.to] = True
                    cl.sendText(msg.to,"Auto Purge already On 􀜁􀄯ok􏿿")
            elif "mimic:" in pesan.lower():
                xpesan = pesan.lower()
                xres = xpesan.replace("mmc:","")
                if xres == "off":
                    periksa['mimic'] = False
                    cl.sendText(msg.to,"Mimic alread Off 􀜁􀄰no􏿿")
                elif xres == "on":
                    periksa['mimic'] = True
                    cl.sendText(msg.to,"Mimic already On 􀜁􀄯ok􏿿")
            elif "block qr:" in pesan.lower():
                xpesan = pesan.lower()
                xres = xpesan.replace("block qr:","")
                if xres == "off":
                    del periksa['lockqr'][msg.to]
                    cl.sendText(msg.to,"QR already Off 􀜁􀄰no􏿿")
                elif xres == "on":
                    periksa['lockqr'][msg.to] = True
                    cl.sendText(msg.to,"QR already On 􀜁􀄯ok􏿿")
            elif "blockinvite:" in pesan.lower():
                xpesan = pesan.lower()
                xres = xpesan.replace("blockinvite:","")
                if xres == "off":
                    del periksa['autocancel'][msg.to]
                    cl.sendText(msg.to,"Auto Cancel already Off 􀜁􀄰no􏿿")
                elif xres == "on":
                    periksa['autocancel'][msg.to] = True
                    cl.sendText(msg.to,"Auto Cancel already On ??􀄯ok􏿿")
            elif "protection:" in pesan.lower():
                xpesan = pesan.lower()
                xres = xpesan.replace("protection:","")
                if xres == "off":
                    del periksa['protect'][msg.to]
                    del periksa['lockqr'][msg.to]
                    del periksa['autopurge'][msg.to]
                    del periksa['autocancel'][msg.to]
                    cl.sendText(msg.to,"Protection already Off 􀜁􀄰no􏿿")
                elif xres == "on":
                    periksa['protect'][msg.to] = True
                    periksa['autocancel'][msg.to] = True
                    periksa['lockqr'][msg.to] = True
                    periksa['autopurge'][msg.to] = True
                    cl.sendText(msg.to,"Protection already On 􀜁􀄯ok􏿿")
            elif "myset" in pesan.lower():
                if msg.to in periksa['protect']:
                    protect = "on √"
                else:
                    protect = "off ×"
                if msg.to in periksa['autopurge']:
                    autopurge = "on √"
                else:
                    autopurge = "off ×"
                if msg.to in periksa['lockqr']:
                    lockqr = "on √"
                else:
                    lockqr = "off ×"
                if msg.to in periksa['autocancel']:
                    autocancel = "on √"
                else:
                    autocancel = "off ×"
                if periksa['autolike'] == True:
                    autolike = "on √"
                else:
                     autolike = "off ×"
                if periksa['autoadd'] == True:
                    autoadd = "on √"
                else:
                     autoadd = "off ×"
                if periksa['autorejc'] == True:
                    autorejc = "on √"
                else:
                     autorejc = "off ×"     
                if periksa['autojoin'] == "all":
                    autojoin = "all √"
                elif periksa['autojoin'] == "wl":
                     autojoin = "wl √"
                else:
                    autojoin = "off ×"
#                liketype = periksa['like']
                cl.sendText(msg.to,"  ❂~Com Sett~❂ \n\n• Protect: %s\n• Blockinvite: %s\n• Autopurge: %s\n• Block qr: %s\n|• Autolike: %s\n• Autoadd: %s\n• Autoreject: %s\n• Autojoin: %s\n\nThe End"%(protect,autocancel,autopurge,lockqr,autolike,autoadd,autorejc,autojoin)) 
            elif "mimic @" in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    G = cl.getGroupIdsJoined()
                    cgroup = cl.getGroups(G)
                    ngroup = ""
                    for mention in mentionees:
                        periksa['tmimic'][mention['M']] = True
                        cl.sendText(msg.to,"Added 􀜁􀄯ok􏿿")
                        with open('settingan.json', 'w') as fp:
                            json.dump(periksa, fp, sort_keys=True, indent=4)
            elif "unmimic @" in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    G = cl.getGroupIdsJoined()
                    cgroup = cl.getGroups(G)
                    ngroup = ""
                    for mention in mentionees:
                        del periksa['tmimic'][mention['M']]
                        cl.sendText(msg.to,"Target Mimic has been Removed")
                        with open('settingan.json', 'w') as fp:
                            json.dump(periksa, fp, sort_keys=True, indent=4)
            elif "autoreject:" in pesan.lower():
                xpesan = pesan.lower()
                xres = xpesan.replace("autoreject:","")
                if xres == "off":
                    periksa['autorejc'] = False
                    cl.sendText(msg.to,"Auto Reject already Off 􀜁􀄰no􏿿")
                elif xres == "on":
                    periksa['autorejc'] = True
                    cl.sendText(msg.to,"Auto Reject already On 􀜁􀄯ok􏿿")
            elif "rgroups" in pesan.lower():
                g1 = cl.getGroupIdsInvited()
                g2 = kk.getGroupIdsInvited()
                g3 = wb.getGroupIdsInvited()
                for x in g1:
                    cl.rejectGroupInvitation(x)
                pass
                cl.sendText(msg.to,"Done 􀜁􀄯ok􏿿")
                for x in g2:
                    kk.rejectGroupInvitation(x)
                pass
                kk.sendText(msg.to,"Done 􀜁􀄯ok􏿿")
                for x in g3:
                    wb.rejectGroupInvitation(x)
                pass
                wb.sendText(msg.to,"Done 􀜁􀄯ok􏿿")
            elif "say" == pesan.lower():
                     G = cl.getGroup(msg.to)
                     G.preventJoinByTicket = False
                     cl.updateGroup(G)
                     Ti = cl.reissueGroupTicket(msg.to)
                     kk.acceptGroupInvitationByTicket(msg.to,Ti)
                     wb.acceptGroupInvitationByTicket(msg.to,Ti)
                     X = kk.getGroup(msg.to)
                     X.preventJoinByTicket = True
                     kk.updateGroup(X) 
            elif "set on" == pesan.lower():
                if msg.to in sider['readPoint']:
                    try:
                        del sider['readPoint'][msg.to]
                        del sider['readMember'][msg.to]
                        del sider['setTime'][msg.to]
                    except:
                        pass
                    sider['readPoint'][msg.to] = msg.id
                    sider['readMember'][msg.to] = ""
                    sider['setTime'][msg.to] = datetime.now().strftime('%H:%M:%S')
                    sider['ROM'][msg.to] = {}
                    with open('sider.json', 'w') as fp:
                      json.dump(sider, fp, sort_keys=True, indent=4)
                    cl.sendText(msg.to,"Set already on 􀜁􀄯ok􏿿")
                else:
                    try:
                        del sider['readPoint'][msg.to]
                        del sider['readMember'][msg.to]
                        del sider['setTime'][msg.to]
                    except:
                        pass
                    sider['readPoint'][msg.to] = msg.id
                    sider['readMember'][msg.to] = ""
                    sider['setTime'][msg.to] = datetime.now().strftime('%H:%M:%S')
                    sider['ROM'][msg.to] = {}
                    with open('sider.json', 'w') as fp:
                       json.dump(sider, fp, sort_keys=True, indent=4)
                    cl.sendText(msg.to,"Set On 􀜁􀄯ok􏿿")
                    #print sider
            elif "set off" == pesan.lower():
                if msg.to not in sider['readPoint']:
                    cl.sendText(msg.to,"Set already Off 􀜁􀄰no􏿿")
                else:
                    try:
                       del sider['readPoint'][msg.to]
                       del sider['readMember'][msg.to]
                       del sider['setTime'][msg.to]
                    except:
                       pass
                    cl.sendText(msg.to,"Set already Off 􀜁􀄰no􏿿")
            elif "set view" == pesan.lower():
                    if msg.to in sider['readPoint']:
                        if sider["ROM"][msg.to].items() == []:
                             cl.sendText(msg.to, "Result:\nNone")
                        else:
                            chiya = []
                            for rom in sider["ROM"][msg.to].items():
                                chiya.append(rom[1])
                                
                            cmem = cl.getContacts(chiya)
                            zx = ""
                            zxc = ""
                            zx2 = []
                            xpesan = 'Result:\n'
                            for x in range(len(cmem)):
                                xname = str(cmem[x].displayName)
                                pesan = ''
                                pesan2 = pesan+"@a\n"
                                xlen = str(len(zxc)+len(xpesan))
                                xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                zx = {'S':xlen, 'E':xlen2, 'M':cmem[x].mid}
                                zx2.append(zx)
                                zxc += pesan2
                            msg.contentType = 0
            
                            #print zxc
                            msg.text = xpesan+ zxc + "\nCek time: %s\nNow time: %s"%(sider['setTime'][msg.to],datetime.now().strftime('%H:%M:%S'))
                            lol ={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}
                            #print lol
                            msg.contentMetadata = lol
                            try:
                              cl.sendMessage(msg)
                            except Exception as error:
                                  #print error
                              pass
                
            
                    else:
                        cl.sendText(msg.to, "Set not on 􀜁􀄰no􏿿")
            elif "mygroups" == pesan.lower():
                    G = cl.getGroupIdsJoined()
                    cgroup = cl.getGroups(G)
                    ngroup = ""
                    for x in range(len(cgroup)):
                       ngroup += "\n["+ str(x) +"] " + cgroup[x].name + " | Members: " + str(len(cgroup[x].members))
                    pass
                    cl.sendText(msg.to,"List Groups:\n%s\n\nTotal Groups: %s"%(ngroup,str(len(cgroup))))
            elif "kontak:" in pesan.lower():
                   umid = pesan.replace('kontak:','')
                   msg.contentType = 13
                   msg.text = None
                   msg.contentMetadata = {'mid': umid}
                   cl.sendMessage(msg)
                   
            elif "Contact" in msg.text:
                key = eval(msg.contentMetadata["MENTION"])
                key1 = key["MENTIONEES"][0]["M"]                
                mmid = cl.getContact(key1)
                msg.contentType = 13
                msg.contentMetadata = {"mid": key1}
                cl.sendMessage(msg)
                
            elif "Getall" in msg.text:
                key = eval(msg.contentMetadata["MENTION"])
                key1 = key["MENTIONEES"][0]["M"]
                contact = cl.getContact(key1)
                cu = cl.channel.getCover(key1)
                path = str(cu)
                image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                try:
                    cl.sendText(msg.to,"Nama :\n" + contact.displayName + "\n\nBio :\n" + contact.statusMessage)
                    cl.sendText(msg.to,"Profile Picture " + contact.displayName + "\n􀄃􀉛itu􏿿􀄃􀉛itu􏿿􀄃􀉛itu􏿿")
                    cl.sendImageWithURL(msg.to,image)
                    cl.sendText(msg.to,"Cover " + contact.displayName + "\n􀄃􀉛itu􏿿􀄃􀉛itu􏿿􀄃􀉛itu􏿿")
                    cl.sendImageWithURL(msg.to,path)
                except:
                    pass                   
#            elif "cari @" in pesan.lower():
#                   if 'MENTION' in msg.contentMetadata.keys() != None:
#                    names = re.findall(r'@(\w+)', msg.text)
#                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
#                    mentionees = mention['MENTIONEES']
#                    G = cl.getGroupIdsJoined()
#                    cgroup = cl.getGroups(G)
#                    ngroup = ""
#                    for mention in mentionees:
#                      for x in range(len(cgroup)):
#                        gMembMids = [contact.mid for contact in cgroup[x].members]
#                        if mention['M'] in gMembMids:
#                            ngroup += "\n" + cgroup[x].name + " | Members: " + str(len(cgroup[x].members))    
#                    if ngroup == "":
#                          cl.sendText(msg.to, "Tidak ditemukan")
#                    else:
#                        cl.sendText(msg.to,"Ada di Group:\n%s\n"%(ngroup))
            elif "link on" == pesan.lower():
                if msg.toType == 2:
                    X = cl.getGroup(msg.to)
                    X.preventJoinByTicket = False
                    cl.updateGroup(X)
                    gurl = cl.reissueGroupTicket(msg.to)
                    cl.sendText(msg.to,"http://line.me/ti/g/"+gurl)
                else:
                    pass
            elif "Gn " in pesan:
                if msg.toType == 2:
                    X = cl.getGroup(msg.to)
                    X.name = msg.text.replace("Gn ","")
                    cl.updateGroup(X)
                else:
                    cl.sendText(msg.to,"It can't be used besides the group.")
            elif "link off" == pesan.lower():
                if msg.toType == 2:
                    X = cl.getGroup(msg.to)
                    X.preventJoinByTicket = True
                    cl.updateGroup(X)
                    cl.sendText(msg.to,"QR already Off 􀜁􀄯ok􏿿")
                else:
                    pass
            elif "gid" == pesan.lower():
                cl.sendText(msg.to,msg.to)
            elif "mid" == pesan.lower():
                cl.sendText(msg.to,msg.from_)
            elif pesan.lower() in ["sp","speed","speed"]:
                start = time.time()
                cl.sendText(msg.to, "Loading􏿿")
                elapsed_time = time.time() - start
                cl.sendText(msg.to, "%s sec" % (elapsed_time))
                kk.sendText(msg.to, "%s sec" % (elapsed_time))
                wb.sendText(msg.to, "%s sec" % (elapsed_time))
            elif "@bye" == pesan.lower():
                wb.leaveGroup(msg.to)
                kk.leaveGroup(msg.to)
            elif "wl on" == pesan.lower():
                periksa["addwl"][msg.to] = True
                cl.sendText(msg.to,"Send contact")
            elif "wl off" == pesan.lower():
                del periksa["addwl"][msg.to]
                cl.sendText(msg.to,"Already Off")
            elif "unwl on" == pesan.lower():
                periksa["delwl"][msg.to] = True
                cl.sendText(msg.to,"Send contact ")
            elif "unwl off" == pesan.lower():
                del periksa["delwl"][msg.to]
                cl.sendText(msg.to,"Already Off")
            elif "join " == pesan:
                 xlink = msg.text.replace("join ","")
                 ticket = xlink.split("/ti/g/")
                 try:
                   group = cl.findGroupByTicket(ticket[1])
                   cl.acceptGroupInvitationByTicket(group.id,ticket[1])
                   kk.acceptGroupInvitationByTicket(group.id,ticket[1])
                   wb.acceptGroupInvitationByTicket(group.id,ticket[1])
                   cl.sendText(msg.to,"Joined to %s"%(group.name))
                   kk.sendText(msg.to,"Joined to %s"%(group.name))
                   wb.sendText(msg.to,"Joined to %s"%(group.name))
                 except:
                     pass
            elif "gift:on" == pesan.lower():
                periksa["gift"][msg.to] = True
                cl.sendText(msg.to,"Send contact 􀜁􀅪Doctor􏿿")
            elif "gift on:" in pesan.lower():
                xpesan = pesan.lower()
                xres = xpesan.replace("gift on:","")
                jumlah = int(xres)
                if jumlah >= 999:
                    cl.sendText(msg.to,"Are you fucking kidding me? 􀜁􀄶Not Bad􏿿")
                else:
                  periksa["gift2jumlah"] = jumlah
                  periksa["gift2"][msg.to] = True
                  cl.sendText(msg.to,"Send contact 􀜁􀅪Doctor􏿿")
            elif "ban on" == pesan.lower():
                periksa["addbanmode"][msg.to] = True
                cl.sendText(msg.to,"Send contact 􀜁􀅪Doctor􏿿")
            elif "ban off" == pesan.lower():
                del periksa["addbanmode"][msg.to]
                cl.sendText(msg.to,"Already Off 􀜁􀄯ok􏿿")
            elif "unban on" == pesan.lower():
                periksa["delbanmode"][msg.to] = True
                cl.sendText(msg.to,"Send contact")
            elif "unban off" == pesan.lower():
                del periksa["delbanmode"][msg.to]
                cl.sendText(msg.to,"Already Off")
            elif "wl add @" in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        if mention['M'] in periksa["wl"]:
                            cl.sendText(msg.to,"Contact already in list")
                        else:
                            periksa["wl"][mention['M']] = True
                            with open('settingan.json', 'w') as fp:
                                json.dump(periksa, fp, sort_keys=True, indent=4)
                            cl.sendText(msg.to,"Added 􀜁􀄯ok􏿿")
            elif "wl del @" in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        if mention['M'] in periksa["wl"]:
                            del periksa["wl"][mention['M']]
                            with open('settingan.json', 'w') as fp:
                                json.dump(periksa, fp, sort_keys=True, indent=4)
                            cl.sendText(msg.to,"Deleted 􀜁􀄯ok􏿿")
                        else:
                            cl.sendText(msg.to,"Contact not in list")
            elif "ban add @" in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        if mention['M'] in periksa["banlist"]:
                            cl.sendText(msg.to,"Sudah dalam banlist")
                        elif mention['M'] in Bots or mention['M'] in periksa["wl"]:
                            cl.sendText(msg.to,"Can't banned wl")
                        else:
                            periksa["banlist"][mention['M']] = True
                            with open('settingan.json', 'w') as fp:
                                json.dump(periksa, fp, sort_keys=True, indent=4)
                            cl.sendText(msg.to,"Added 􀜁􀄯ok􏿿")
            elif "ban del @" in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        if mention['M'] in periksa["banlist"]:
                            del periksa["banlist"][mention['M']]
                            with open('settingan.json', 'w') as fp:
                                json.dump(periksa, fp, sort_keys=True, indent=4)
                            cl.sendText(msg.to,"Deleted 􀜁􀄯ok􏿿")
                        else:
                            cl.sendText(msg.to,"Contact not in list")
            elif "cek ban" == pesan.lower():
                if periksa["banlist"] == {}:
                    cl.sendText(msg.to,"Nothing 􀜁􀄶Not Bad􏿿")
                else:
                    mc = []
                    for mi_d in periksa["banlist"]:
                        mc.append(mi_d)
                    pass
                    cban = cl.getContacts(mc)
                    nban = []
                    for x in range(len(cban)):
                        nban.append(cban[x].displayName)
                    pass
                    jo = "\n• ".join(str(i) for i in nban)
                    cl.sendText(msg.to,"• List Banned •\n\n• %s\n\nTotal Banlist: %s"%(jo,str(len(cban))))
#            elif "cek ban" == pesan.lower():
#                if msg.toType == 2:
#                    group = cl.getGroup(msg.to)
#                    gMembMids = [contact.mid for contact in group.members]
#                    matched_list = []
#                    for tag in periksa["banlist"]:
#                        matched_list+=filter(lambda str: str == tag, gMembMids)
#                    cocoa = []
#                    for mm in matched_list:
#                        cocoa.append(mm)
#                    pass
#                    cban = cl.getContacts(cocoa)
#                    nban = []
#                    for x in range(len(cban)):
#                        nban.append(cban[x].displayName)
#                   pass
#                   jo = "\n☠ ".join(str(i) for i in nban)
#                   if cocoa != []:
#                        cl.sendText(msg.to,"☠ List Banned dalam Group ini ☠ \n☠ %s\n\nTotal Banlist: %s"%(jo,str(len(cban))))
#                    else:
#                        cl.sendText(msg.to,"Tidak ada")
            elif "whitelist" == pesan.lower():
                if periksa["wl"] == {}:
                    cl.sendText(msg.to,"Nothing 􀜁􀄶Not Bad􏿿")
                else:
                    mc = []
                    for mi_d in periksa["wl"]:
                        mc.append(mi_d)
                    pass
                    cban = cl.getContacts(mc)
                    nban = []
                    for x in range(len(cban)):
                        nban.append(cban[x].displayName)
                    pass
                    jo = "\n• ".join(str(i) for i in nban)
                    cl.sendText(msg.to,"• List Wl •\n\n• %s\n\nTotal Wl: %s"%(jo,str(len(cban))))
                    
            elif "mimic list" == pesan.lower():
                if periksa["tmimic"] == {}:
                    cl.sendText(msg.to,"Nothing 􀜁􀄶Not Bad􏿿")
                else:
                    mc = []
                    for mi_d in periksa["tmimic"]:
                        mc.append(mi_d)
                    pass
                    cban = cl.getContacts(mc)
                    nban = []
                    for x in range(len(cban)):
                        nban.append(cban[x].displayName)
                    pass
                    jo = "\n• ".join(str(i) for i in nban)
                    cl.sendText(msg.to,"• List mimic: •\n\n• %s\n\nTotal: %s"%(jo,str(len(cban))))
            elif "me" == pesan.lower():
                      msg.contentType = 13
                      msg.text = None
                      msg.contentMetadata = {'mid': msg.from_}
                      cl.sendMessage(msg)
            elif "cancell" == pesan.lower():
                if msg.toType == 2:
                    group = cl.getGroup(msg.to)
                    gMembMids = [contact.mid for contact in group.invites]
                    if group.invitee is None:
               #     for _mid in gMembMids:
                        cl.cancelGroupInvitation(msg.to,[_mid])
                        cl.sendText(msg.to, "Done")
   #         elif "cancel" == pesan.lower():
   #                 group = cl.getGroup(msg.to)
   #                 if group.invitee is None:
                        #cl.sendText(op.message.to, "Nothing pending invites")
         #           else:
         #               gInviMids = [contact.mid for contact in group.invitee]
                        #cl.cancelGroupInvitation(msg.to, gInviMids)
         #               cl.sendText(msg.to, "Done")
            elif "kick " in msg.text.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        try:
                            kicker=random.choice(KAC)
                            kicker.kickoutFromGroup(msg.to, [mention['M']])							
                        except:
                            try:
                                kicker=random.choice(KAC)
                                kicker.kickoutFromGroup(msg.to, [mention['M']])								
                            except:
                                cl.kickoutFromGroup(msg.to, [mention['M']])
            elif "vkick " in msg.text.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        try:
                            kicker=random.choice(KAC)
                            kicker.kickoutFromGroup(msg.to, [mention['M']])							
                        except:
                            try:
                                kicker=random.choice(KAC)
                                kicker.kickoutFromGroup(msg.to, [mention['M']])								
                            except:
                                cl.kickoutFromGroup(msg.to, [mention['M']])	                          
            elif "nuke" == pesan.lower():
                if msg.toType == 2:
                    gs = cl.getGroup(msg.to)
                    targets = []
                    for g in gs.members:
                        if g.mid not in Bots:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendText(msg.to,"Target not found")
                    else:
                        for target in targets:
                            try:
                                klist=[cl,kk,wb]
                                kicker=random.choice(klist)
                                kicker.kickoutFromGroup(msg.to,[target])
                            except:
                                pass
            elif "clean ban" == pesan.lower():
                if msg.toType == 2:
                    group = cl.getGroup(msg.to)
                    gMembMids = [contact.mid for contact in group.members]
                    matched_list = []
                    for tag in periksa["banlist"]:
                        matched_list+=filter(lambda str: str == tag, gMembMids)
                    if matched_list == []:
                        cl.sendText(msg.to,"Nothing banned user")
                        return
                    for jj in matched_list:
                      try:
                        wb.kickoutFromGroup(msg.to,[jj])
                      except:
                        kk.kickoutFromGroup(msg.to,[jj])
                    kk.sendText(msg.to,"Done 􀜁􀄯ok􏿿")
            elif "clear ban" in pesan.lower():
                periksa['banlist'] = {}
                with open('settingan.json', 'w') as fp:
                    json.dump(periksa, fp, sort_keys=True, indent=4)
                cl.sendText(msg.to,"Done")
            elif "clear wl" in pesan.lower():
                periksa['wl'] = {}
                with open('settingan.json', 'w') as fp:
                    json.dump(periksa, fp, sort_keys=True, indent=4)
                cl.sendText(msg.to,"Done")
            elif "gc" == pesan.lower():
              if msg.toType == 2:
                g = cl.getGroup(msg.to)
                gc = g.creator.mid
                gn = g.creator.displayName
                msg.contentType = 13
                msg.contentMetadata = {'mid': gc}
                try:
                    kk.sendText(msg.to,"This group has been created by "+str(gn))
                    kk.sendMessage(msg)
                except:
                    try:
                        wb.sendText(msg.to,"This group has been created by "+str(gn))
                        wb.sendMessage(msg)
                    except:
                        cl.sendText(msg.to,"This group has been created by "+str(gn))
            elif "message change:" == pesan.lower():
                xpesan = pesan.lower()
                xres = xpesan.replace("message change:","")
                periksa['message'] = xres
                cl.sendText(msg.to,"Message changed to "+xres)
            elif "message cek" in pesan.lower():
                if periksa['message'] == "":
                    cl.sendText(msg.to,"Nothing 􀜁􀄶Not Bad􏿿")
                else:
                    cl.sendText(msg.to,"Message change to: \n"+str(periksa['message']))
            elif "backup" in pesan.lower():
                cl.updateDisplayPicture(backup.pictureStatus)
                cl.updateProfile(backup)
            elif "copy @" in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        try:
                            profile = cl.getProfile()
                            backup.displayName = profile.displayName
                            backup.statusMessage = profile.statusMessage
                            backup.pictureStatus = profile.pictureStatus
                            cl.cloneContactProfile(mention['M'])
                            cl.sendText(msg.to,"Done")
                        except Exception as error:
                            pass
            elif "gift1" == pesan.lower():
                msg.contentType = 9
                msg.contentMetadata = { 'STKPKGID':'2821',
                                        'PRDTYPE':'STICKER',
                                        'MSGTPL':'4'}
                msg.text = None
                cl.sendMessage(msg)
            elif "gift2" == pesan.lower():
                msg.contentType = 9
                msg.contentMetadata = { 'STKPKGID':'3172',
                                        'PRDTYPE':'STICKER',
                                        'MSGTPL':'2'}
                msg.text == None
                cl.sendMessage(msg)
            elif "gift3" == pesan.lower():
                msg.contentType = 9
                msg.contentMetadata = { 'STKPKGID':'4333',
                                        'PRDTYPE':'STICKER',
                                        'MSGTPL':'3'}
                msg.text = None
                cl.sendMessage(msg)
            elif "gift4" == pesan.lower():
                msg.contentType = 9
                msg.contentMetadata = { 'STKPKGID':'3002',
                                        'PRDTYPE':'STICKER',
                                        'MSGTPL':'4'}
                msg.text = None
                cl.sendMessage(msg)
            elif "gift5" == pesan.lower():
                msg.contentType = 9
                msg.contentMetadata = { 'STKPKGID':'6083',
                                        'PRDTYPE':'STICKER',
                                        'MSGTPL':'1'}
                msg.text = None
                cl.sendMessage(msg)
            elif "voice:" in pesan.lower():
                xpesan = pesan.lower()
                xres = xpesan.replace("voice:","")
                tts = gTTS(text=xres, lang='id')
                path = '%s/pythonLine-vn.data' % (tempfile.gettempdir())
                ac = tts.save(path)
                cl.sendAudio(msg.to,path)
                os.remove(path) 
            elif "tagmem" == pesan.lower():
                    group = cl.getGroup(msg.to)
                    nama = [contact.mid for contact in group.members]
                    nm1,nm2,nm3,nm4,nm5,jml = [],[],[],[],[],len(nama)
                    if jml <=100:
                        MENTION(msg.to,nama)
                    elif jml > 100 and jml < 200:
                        for i in range(0,100):
                            nm1 += [nama[i]]
                        MENTION(msg.to,nm1)
                        for i in range(100,len(nama)-1):
                            nm2 += [nama[i]]
                        MENTION(msg.to,nm2)
                    elif jml > 200 and jml < 300:
                        for i in range(0,100):
                            nm1 += [nama[i]]
                        MENTION(msg.to,nm1)
                        for i in range(100,200):
                            nm2 += [nama[i]]
                        MENTION(msg.to,nm2)
                        for i in range(200,len(nama)-1):
                            nm3 += [nama[i]]
                        MENTION(msg.to,nm3)
                    elif jml > 300 and jml < 400:
                        for i in range(0,100):
                            nm1 += [nama[i]]
                        MENTION(msg.to,nm1)
                        for i in range(100,200):
                            nm2 += [nama[i]]
                        MENTION(msg.to,nm2)
                        for i in range(200,300):
                            nm3 += [nama[i]]
                        MENTION(msg.to,nm3)
                        for i in range(300,len(nama)-1):
                            nm4 += [nama[i]]
                        MENTION(msg.to,nm4)
                    elif jml > 400 and jml < 500:
                        for i in range(0,100):
                            nm1 += [nama[i]]
                        MENTION(msg.to,nm1)
                        for i in range(100,200):
                            nm2 += [nama[i]]
                        MENTION(msg.to,nm2)
                        for i in range(200,300):
                            nm3 += [nama[i]]
                        MENTION(msg.to,nm3)
                        for i in range(300,400):
                            nm4 += [nama[i]]
                        MENTION(msg.to,nm4)
                        for i in range(400,len(nama)-1):
                            nm5 += [nama[i]]
                        MENTION(msg.to,nm5)
                  
            elif "Sider on" in msg.text:
                try:
                    del cctv['point'][msg.to]
                    del cctv['sidermem'][msg.to]
                    del cctv['cyduk'][msg.to]
                except:
                    pass
                cctv['point'][msg.to] = msg.id
                cctv['sidermem'][msg.to] = ""
                cctv['cyduk'][msg.to]=True
                wait["Sider"] = True
                cl.sendText(msg.to,"Siap On Cek Sider")
                
            elif "Sider off" in msg.text:
                if msg.to in cctv['point']:
                    cctv['cyduk'][msg.to]=False
                    wait["Sider"] = False
                    cl.sendText(msg.to, "Cek Sider Off")
                else:
                    cl.sendText(msg.to, "Heh Belom Di Set")
                
            elif "Bcgroup:" in pesan:
                xres = pesan.replace("Bcgroup:","")
                group = cl.getGroup(msg.to)
                mem = [contact.mid for contact in group.members]
                cmem = cl.getContacts(mem)
                nc = ""
                for x in range(len(cmem)):
                  try:
                    cl.sendText(cmem[x].mid,xres)
                    nc += "\n" + cmem[x].displayName
                  except:
                    pass
                pass
                cl.sendText(msg.to,"Success BC to :\n%s\n\nTotal Members: %s"%(nc,str(len(cmem))))
            elif "Say " in pesan:
                xres = pesan.replace("Say ","")
                cl.sendText(msg.to,xres)
                kk.sendText(msg.to,xres)
                wb.sendText(msg.to,xres)
            elif msg.text in ["Mypict"]:
                    profile = cl.getProfile()
                    h = cl.getContact(mid)
                    try:
                         cl.sendImageWithURL(msg.to, "http://dl.profile.line-cdn.net/" + profile.pictureStatus)
                         cl.sendText(msg.to,"Profile Picture " + contact.displayName)
                    except:
                       pass
                       
            elif msg.text in ["Mycover"]:
                    h = cl.getContact(mid)
                    cu = cl.channel.getCover(mid)          
                    path = str(cu)
                    cl.sendImageWithURL(msg.to, path)

            elif "Getinfo" in msg.text:
                profile = cl.getProfile()
                h = cl.getContact(mid)
                cu = cl.channel.getCover(mid)
                path = str(cu)
                image = "http://dl.profile.line-cdn.net/" + profile.pictureStatus
                try:
                    cl.sendText(msg.to,"Nama :\n" + h.displayName + "\n\nStatus :\n" + h.statusMessage)
                    cl.sendText(msg.to,"Profile Picture " + h.displayName)
                    cl.sendImageWithURL(msg.to,image)
                    cl.sendText(msg.to,"Cover " + contact.displayName)
                    cl.sendImageWithURL(msg.to,path)
                except:
                    pass
            elif msg.text in ["Name"]:
                    h = cl.getContact(mid)
                    cl.sendText(msg.to,"===[DisplayName]===\n" + h.displayName)
#-----------------------------------------
            elif msg.text in ["Bio"]:
                    h = cl.getContact(mid)
                    cl.sendText(msg.to,"===[StatusMessage]===\n" + h.statusMessage)                                                                                 


            elif "Pictgroups" in pesan:
                  group = cl.getGroup(msg.to)
                  path = "http://dl.profile.line-cdn.net/" + group.pictureStatus
                  cl.sendImageWithURL(msg.to,path)

            elif "change pict" == pesan.lower():
                  periksa['cpp11'][msg.to] = True
                  with open('settingan.json', 'w') as fp:
                       json.dump(periksa, fp, sort_keys=True, indent=4)
                  cl.sendText(msg.to,"Send your image")
            elif "k1 changepict" == pesan.lower():
                  periksa['cpp1'][msg.to] = True
                  with open('settingan.json', 'w') as fp:
                       json.dump(periksa, fp, sort_keys=True, indent=4)
                  kk.sendText(msg.to,"Send your image")
            elif "k2 changepict" == pesan.lower():
                  periksa['cpp2'][msg.to] = True
                  with open('settingan.json', 'w') as fp:
                       json.dump(periksa, fp, sort_keys=True, indent=4)
                  wb.sendText(msg.to,"Send your image")
            elif "all changepict" == pesan.lower():
                  periksa['cpp1'][msg.to] = True
                  with open('settingan.json', 'w') as fp:
                       json.dump(periksa, fp, sort_keys=True, indent=4)
                  kk.sendText(msg.to,"Send your image")
                  periksa['cpp2'][msg.to] = True
                  with open('settingan.json', 'w') as fp:
                       json.dump(periksa, fp, sort_keys=True, indent=4)
                  wb.sendText(msg.to,"Send your image")                
#----------------TIMES---------------------------- RG
            elif "change pict group" == pesan.lower():
                periksa["cpg"][msg.to] = True
                with open('settingan.json', 'w') as fp:
                         json.dump(periksa, fp, sort_keys=True, indent=4) 
                cl.sendText(msg.to,"Send Picture")

            elif msg.text in ["Times","Waktu"]:
                timeNow = datetime.now()
                timeHours = datetime.strftime(timeNow,"(%H:%M)")
                day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
                bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                inihari = datetime.today()
                hr = inihari.strftime('%A')
                bulan = inihari.strftime('%m')
                for i in range(len(day)):
                    if hr == day[i]: hasil = hari[i]
                for k in range(0, len(bulan)):
                    if bulan == str(k): bulan = bulan[k-1]
                rst = hasil + ", " + inihari.strftime('%d') + " - " + bulan + " - " + inihari.strftime('%Y') + "\nJam : [ " + inihari.strftime('%H:%M:%S') + " ]"
                cl.sendText(msg.to, rst)
            elif msg.text in ["Tanggal"]:
                cl.sendText(msg.to,datetime.today().strftime('Tanggal (%d/%m/%Y)\nJam       (%H:%M:%S.wib)'))
 
            elif "Ping" == pesan:
                try:
                    wb.findAndAddContactsByMid(msg.to)
                    kk.findAndAddContactsByMid(msg.to)
                except:
                    pass
                kk.sendText(msg.to,"PONG!!!")
                wb.sendText(msg.to,"PONG!!!")
            elif "Respon" == pesan:
                cl.sendText(msg.to,"(︶︹︺)")
                kk.sendText(msg.to,"(︶︹︺)")
                wb.sendText(msg.to,"(︶︹︺)")
#            elif "FUCK" == pesan:
#                try:
#                    wb.findAndAddContactsByMid(msg.to)
#                    kk.findAndAddContactsByMid(msg.to)
#                except:
##                    pass
 #               cl.sendText(msg.to,"┌∩┐(◣_◢)┌∩┐")
 #               kk.sendText(msg.to,"┌∩┐(◣_◢)┌∩┐")
 #               wb.sendText(msg.to,"┌∩┐(◣_◢)┌∩┐")

            elif "mid @" in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        try:
                           cl.sendText(msg.to,str(mention['M']))
                        except Exception as e:
                            pass
            elif "status @" in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        try:
                            profile = cl.getContact(mention['M'])
                            cl.sendText(msg.to,str(profile.statusMessage))
                        except Exception as e:
                            print (e)
            elif "name @" in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        try:
                            profile = cl.getContact(mention['M'])
                            cl.sendText(msg.to,str(profile.displayName))
                        except Exception as e:
                            pass
            elif "pict @" in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        try:
                            profile = cl.getContact(mention['M'])
                            cl.sendImageWithURL(msg.to,"http://dl.profile.line.naver.jp/"+profile.pictureStatus)
                        except Exception as e:
                            pass
            elif "cover @" in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        try:
                            cu = cl.channel.getCover(mention['M'])
                            cl.sendImageWithURL(msg.to,cu)
                        except Exception as e:
                            pass
            elif "uinfo @" in msg.text.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        try:
                            profile = cl.getContact(mention['M'])
                            path = "http://dl.profile.line-cdn.net/" + contact.pictureStatus                            
                            cl.sendText(msg.to,"Name: " + str(profile.displayName) + "\nStatus: " + (profile.statusMessage) + "\nMid: " + (mention['M']) + "http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                            cl.sendImageWithUrl(msg.to, path)                            
                        except Exception as e:
                            pass                            
            elif "reboot" == pesan.lower():
                cl.sendText(msg.to,"Rebooting")
                restart_program()

#            elif "me ticket" in pesan.lower():
#               tiket = cl._reissueUserTicket()
#               cl.sendText(msg.to, "line.me/ti/p/%20"+tiket)
            elif "kontak: " in pesan.lower():
                   umid = pesan.replace('kontak: ','')
                   msg.contentType = 13
                   msg.text = None
                   msg.contentMetadata = {'mid': umid}
                   cl.sendMessage(msg)
#            elif "Gift." in pesan:
#                xres = pesan.replace("Gift.","")
#                if xres in helpMessage:
#                   pass
#               elif xres == "":
#                    cl.sendText(msg.to,"Invalid input")
#               else:
#                    try:
#                      number = int(xres)
#                    except:
#                        cl.sendText(msg.to,"Invalid input")
#                        
#                    for x in range(0,number):
#                        try:
#                           msg.contentType = 9
#                           msg.contentMetadata = { 'STKPKGID':'2821',
#                                        'PRDTYPE':'STICKER',
#                                        'MSGTPL':'4'}
#                           msg.text = None
#                           cl.sendMessage(msg)
#                        except:
#                            pass

            elif "Leave:" in pesan:
                group_name = pesan.replace('Leave:','')
                G = cl.getGroupIdsJoined()
                cgroup = cl.getGroups(G)
                for x in range(len(cgroup)):
                  if group_name == cgroup[x].name:
                      try:
                         cl.leaveGroup(cgroup[x].id)
                      except:
                          pass
                      try:
                         kk.leaveGroup(cgroup[x].id)
                      except:
                          pass
                      try:
                         wb.leaveGroup(cgroup[x].id)
                      except:
                          pass
                cl.sendText(msg.to,"Done 􀜁􀄯ok􏿿")
#===============[Tranlate Command]====================
            elif "Translate" == pesan:
                try:
                  cl.sendText(msg.to,"Command Translate:\n\n Tr-id to Indonesia \n Tr-th to Thai \n Tr-en to English \n Tr-ja to Japan \n Tr-ms to Malay \n Tr-jw to Jawa \n Tr-it to Italia \n Tr-my to Myanmar \n Tr-fr to French \n Tr-ar to Arabic")
                except:
                   try:
                      cl.sendText(msg.to,"Command Translate:\n\n Tr-id to Indonesia \n Tr-th to Thai \n Tr-en to English \n Tr-ja to Japan \n Tr-ms to Malay \n Tr-jw to Jawa \n Tr-it to Italia \n Tr-my to Myanmar \n Tr-fr to French \n Tr-ar to Arabic")
                   except:
                       cl.sendText(msg.to,"Assists must exist in the group")
            elif "Tr-id" in pesan:
                 xres = pesan.replace("Tr-id","")
                 xres1 = xres.lstrip()
                 xres2 = xres1.replace("","")
                 xres3 = xres2.rstrip()
                 _text = xres3
                 trans = translate(_text,'id')
                 cl.sendText(msg.to,str(trans))
            elif "Tr-en" in pesan:
                 xres = pesan.replace("Tr-en","")
                 xres1 = xres.lstrip()
                 xres2 = xres1.replace("","")
                 xres3 = xres2.rstrip()
                 _text = xres3
                 trans = translate(_text,'en')
                 cl.sendText(msg.to,str(trans))
            elif "Tr-ja" in pesan:
                 xres = pesan.replace("Tr-ja","")
                 xres1 = xres.lstrip()
                 xres2 = xres1.replace("","")
                 xres3 = xres2.rstrip()
                 _text = xres3
                 trans = translate(_text,'ja')
                 cl.sendText(msg.to,str(trans))
            elif "Tr-th" in pesan:
                 xres = pesan.replace("Tr-th","")
                 xres1 = xres.lstrip()
                 xres2 = xres1.replace("","")
                 xres3 = xres2.rstrip()
                 _text = xres3
                 trans = translate(_text,'th')
                 cl.sendText(msg.to,str(trans))
            elif "Tr-jw" in pesan:
                 xres = pesan.replace("Tr-jw","")
                 xres1 = xres.lstrip()
                 xres2 = xres1.replace("","")
                 xres3 = xres2.rstrip()
                 _text = xres3
                 trans = translate(_text,'jw')
                 cl.sendText(msg.to,str(trans))
            elif "Tr-ar" in pesan:
                 xres = pesan.replace("Tr-ar","")
                 xres1 = xres.lstrip()
                 xres2 = xres1.replace("","")
                 xres3 = xres2.rstrip()
                 _text = xres3
                 trans = translate(_text,'ar')
                 cl.sendText(msg.to,str(trans))
            elif "Tr-ms" in pesan:
                 xres = pesan.replace("Tr-ms","")
                 xres1 = xres.lstrip()
                 xres2 = xres1.replace("","")
                 xres3 = xres2.rstrip()
                 _text = xres3
                 trans = translate(_text,'ms')
                 cl.sendText(msg.to,str(trans))
            elif "Tr-my" in pesan:
                 xres = pesan.replace("Tr-my","")
                 xres1 = xres.lstrip()
                 xres2 = xres1.replace("","")
                 xres3 = xres2.rstrip()
                 _text = xres3
                 trans = translate(_text,'my')
                 cl.sendText(msg.to,str(trans))
            elif "Tr-it" in pesan:
                 xres = pesan.replace("Tr-it","")
                 xres1 = xres.lstrip()
                 xres2 = xres1.replace("","")
                 xres3 = xres2.rstrip()
                 _text = xres3
                 trans = translate(_text,'it')
                 cl.sendText(msg.to,str(trans))
            elif "Tr-fr" in pesan:
                 xres = pesan.replace("Tr-fr","")
                 xres1 = xres.lstrip()
                 xres2 = xres1.replace("","")
                 xres3 = xres2.rstrip()
                 _text = xres3
                 trans = translate(_text,'fr')
                 cl.sendText(msg.to,str(trans))

            elif "Wiki:" in pesan:
                cari = pesan.replace('Wiki:','')
                wikipedia.set_lang("id")
                try:
                   ny = wikipedia.summary(cari)
                except Exception as ny:
          
                  cl.sendText(msg.to,"%s"%(ny))     
            elif "Urban:" in pesan:
               cari = pesan.replace('Urban:','')
               try:
                 response = requests.get("http://api.urbandictionary.com/v0/define?term="+cari)
                 data = response.json()
                 num_requested = 0
                 term_list = data['list']
                 num_requested = min(num_requested, len(term_list) - 1)
                 num_requested = max(0, num_requested)
                 definition = term_list[num_requested].get('definition')
                 example = term_list[num_requested].get('example')
                 cl.sendText(msg.to,"Definition:\n\n%s\n\nExample:\n\n%s"%(definition,example))
               except:
                 cl.sendText(msg.to,"Error")
                
            elif "Pict ig " in pesan:
               cari = pesan.replace('Pict ig ','')
               if cari not in helpMessage:
                 try:
                   response = requests.get(cari+"?__a=1")
                   data = response.json()
                   ig_url = data['graphql']['shortcode_media']['display_url']
                   cl.sendImageWithURL(msg.to,ig_url)
                 except Exception as E:
                   cl.sendText(msg.to,"Error")
            elif "vid IG " in pesan:
               cari = pesan.replace('vid IG ','')
               if cari not in helpMessage:
                 try:
                   response = requests.get(cari+"?__a=1")
                   data = response.json()
                   ig_url = data['graphql']['shortcode_media']['display_url']
                   cl.sendVideoWithURL(msg.to,ig_url)
                 except Exception as E:
                   cl.sendText(msg.to,"Error")
            elif "all pict" == pesan.lower():
                if msg.toType == 2:
                    gs = cl.getGroup(msg.to)
                    targets = []
                    for g in gs.members:
                        if g.mid not in Bots:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendText(msg.to,"Target not found")
                    else:
                        for target in targets:
                            try:
                                profile = cl.getContact(target)
                                cl.sendImageWithURL(msg.to,"http://dl.profile.line.naver.jp/"+profile.pictureStatus)
                            except:
                                pass
#===============[Assist Command]====================
            elif "cs:" in pesan:
              xres = pesan.replace("cs:","")
              if len(xres.decode('utf-8')) <= 50000000000000:
                profile = cl.getProfile()
                profile.statusMessage = xres
                cl.updateProfile(profile)
                cl.sendText(msg.to,"Done")
            elif "cn:" in pesan:
              xres = pesan.replace("cn:","")
              if len(xres.decode('utf-8')) <= 10000000000000000:
                profile = cl.getProfile()
                profile.displayName = xres
                cl.updateProfile(profile)
                cl.sendText(msg.to,"Done")
            elif "Kicker1 status:" in pesan:  
              xres = pesan.replace("Kicker1 status:","")
              if len(xres.decode('utf-8')) <= 500:
                profile = kk.getProfile()
                profile.statusMessage = xres
                kk.updateProfile(profile)
                kk.sendText(msg.to,"Done 􀜁􀄯ok􏿿")
            elif "Kicker2 status:" in pesan:
              xres = pesan.replace("Kicker2 status:","")
              if len(xres.decode('utf-8')) <= 500:
                profile = wb.getProfile()
                profile.statusMessage = xres
                wb.updateProfile(profile)
                wb.sendText(msg.to,"Done 􀜁􀄯ok􏿿")
            elif "Kicker1 name:" in pesan:
              xres = pesan.replace("Kicker1 name:","")
              if len(xres.decode('utf-8')) <= 20:
                profile = kk.getProfile()
                profile.displayName = xres
                kk.updateProfile(profile)
                kk.sendText(msg.to,"Done 􀜁􀄯ok􏿿")
            elif "Kicker2 name:" in pesan:
              xres = pesan.replace("kicker2 name:","")
              if len(xres.decode('utf-8')) <= 20:
                profile = wb.getProfile()
                profile.displayName = xres
                wb.updateProfile(profile)
                wb.sendText(msg.to,"Done 􀜁􀄯ok􏿿")
            elif "runtime" in pesan.lower():
                elpsd = datetime.now() - strt
                cl.sendText(msg.to,'Duration : %s'%(elpsd))
            elif "k1 restore" in pesan.lower():
                kk.updateDisplayPicture(backup1.pictureStatus)
                kk.updateProfile(backup1)
            elif "k2 restore" in pesan.lower():
                wb.updateDisplayPicture(backup2.pictureStatus)
                wb.updateProfile(backup2)
            elif "k1 copy @" in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        try:
                            profile = kk.getProfile()
                            backup1.displayName = profile.displayName
                            backup1.statusMessage = profile.statusMessage
                            backup1.pictureStatus = profile.pictureStatus
                            kk.cloneContactProfile(mention['M'])
                            kk.sendText(msg.to,"Done 􀜁􀄯ok􏿿")
                        except Exception as error:
                            print (error)
            elif "k2 copy @" in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        try:
                            profile = kk.getProfile()
                            backup2.displayName = profile.displayName
                            backup2.statusMessage = profile.statusMessage
                            backup2.pictureStatus = profile.pictureStatus
                            wb.cloneContactProfile(mention['M'])
                            wb.sendText(msg.to,"Done 􀜁􀄯ok􏿿")
                        except Exception as error:
                            print (error)
                
        if op.type == 59:
            print (op)


    except Exception as error:
        print (error)


def autolike():
     like = 1000+periksa['like']
     koment = periksa['comment']
     for zx in range(0,20):
        hasil = cl.activity(limit=20)
        if hasil['result']['posts'][zx]['postInfo']['liked'] == False:
          try:    
            cl.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=like)
            cl.comment(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],koment+"Autolike by:\n\nhttp://line.me/ti/p/~")
            kk.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=like)
            kk.comment(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],koment+"Autolike by:\n\nhttp://line.me/ti/p/~")
            wb.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=like)
            wb.comment(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],koment+"Autolike by:\n\nhttp://line.me/ti/p/~")
            #print "Like"
          except:
            pass
        else:
            print ("Already Liked")
def resetchat():
    while True:
        try:
            if periksa['autolike'] == True:
              autolike()
              time.sleep(300)
              autolike()
              time.sleep(300)
              autolike()
              time.sleep(300)
              autolike()
              time.sleep(300)
              autolike()
              time.sleep(200)
            else:
                pass
            kk.removeAllMessages(mid)
            wb.removeAllMessages(Bmid)
            #print "reset"
            time.sleep(400)
        except:
            pass
thread2 = threading.Thread(target=resetchat)
thread2.daemon = True
thread2.start()
#thread2.join()
threads = []

while True:
    try:
        Ops = cl.fetchOps(cl.Poll.rev, 5)
    except EOFError:
        raise Exception("It might be wrong revision\n" + str(cl.Poll.rev))
   
    for Op in Ops:
        if (Op.type != OpType.END_OF_OPERATION):
         try:
            cl.Poll.rev = max(cl.Poll.rev, Op.revision)
            bot(Op)      
         except:
           pass
           
      
