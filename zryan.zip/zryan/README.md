Line self bot
4 bot
1 akun utama 3 akun assist
Hanya akun utama yang bisa jalanin perintah
Edit bagian token dengan token kalian,.
Atau uubah (token="jajaabajaojjsdn")
Ubah jadi (qr=True)
