# NewSatriaPy3
install python3
install pip3
install pip3 rsa , requests , thrift,bs4,gtts,googletrans
install linepy
login via email ganti dengan email dan pasword kamu
