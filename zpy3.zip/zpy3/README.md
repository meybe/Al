#Syndicate Self
me          = Mengirim Kontak Sendiri <br>
speed       = Test Kecepatan Bot <br>
spic <tag>  = Kirim Foto Profile yg di Tag <br>
scover <tag>= Kirim Foto Cover yg di Tag <br>
tagall      = Tag Semua Member dalam Group <br>
ceksider    = Mengecek CCTV <br>
offread     = Tampilkan CCTV <br>
<hr>
source : linepy by https://github.com/fadhiilrachman/
