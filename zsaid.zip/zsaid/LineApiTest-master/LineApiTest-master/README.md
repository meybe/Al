# LineApiTest
just login to Naver LINE with Qr verifier

Please run with Python3  
```
python login_qr.py
```
